# GHRAB AI Migration Kit 1.0.2

Do nového vlákna nahrajte:

1. nejaktuálnější zdrojový ZIP aplikace;
2. tento balíček `ghrab-ai-migration-kit-1.0.2.zip`.

Napište: „Použij integrační prompt obsažený v Migration Kitu. Automaticky zjisti název, App ID a verzi ze zdrojů a proveď nejprve Fázi A bez úprav kódu.“

Prompt je v `prompt-integrace-aplikace-ghrab-ai-core-v3.2.md`. Core v adresáři `core/` je neměnný. Implementace musí navíc publikovat `ai-operations.json`, blok `aiCore` ve Studio manifestu a připravit budoucí consumer workflow.
