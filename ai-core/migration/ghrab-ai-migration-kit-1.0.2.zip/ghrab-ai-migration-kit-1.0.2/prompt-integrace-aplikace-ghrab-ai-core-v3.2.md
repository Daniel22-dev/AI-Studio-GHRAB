# PROMPT PRO INTEGRACI JEDNÉ APLIKACE DO GHRAB AI CORE 1.0.0

Pracujeme na jedné aplikaci z ekosystému AI Studia Gymnázia Ostrava-Hrabůvka. Přikládám její nejaktuálnější zdrojový ZIP.

Nejprve ze skutečných zdrojů automaticky zjisti a v auditu uveď:

- název aplikace;
- stabilní App ID;
- aktuální verzi;
- případný rozdíl mezi verzí ve zdrojích, manifestu, UI, package souboru a buildu.

Tyto údaje po mně nepožaduj, pokud je lze zjistit ze zdrojového balíčku. Jestliže App ID chybí nebo je ve zdrojích více rozporných hodnot, navrhni jednu stabilní hodnotu, popiš rozpor a vyžádej si rozhodnutí až v závěru auditu před implementací. Název ZIPu nepovažuj automaticky za autoritativní zdroj názvu, ID ani verze.

Přikládám:

1. nejaktuálnější zdrojový ZIP aplikace;
2. jeden neměnný balíček `ghrab-ai-migration-kit-1.0.1.zip`.

Migrační balíček obsahuje vydaný GHRAB AI Core 1.0.0, jeho manifest, závazný kontrakt, společnou konformitní sadu a referenční informace. Kód Core ani jeho kontrakt v tomto vlákně neupravuj. Korespondenční asistent 5.9.0 je referenční první integrace.

## Nepřekročitelná pravidla

1. Neimplementuj nový společný AI klient, runtime resolver, gateway transport, Gemini transport, chybovou mapu ani konformitní testy.
2. Integruj přesně **GHRAB AI Core 1.0.0** z přiloženého migračního balíčku. Jeho veřejné API a sémantiku neměň.
3. Core soubory v repozitáři aplikace musejí být bitově shodné s vydanou verzí. Build nebo release test musí ověřit SHA-256 proti manifestu.
4. Nevkládej logiku Core do aplikačního souboru. Aplikační odlišnosti řeš pouze manifestem operací, výstupními schématy, credential/auth hookem, kompatibilním wrapperem a aplikačními testy.
5. Zachovej současný serverless provoz přes osobní Gemini API klíč, dokud runtime konfigurace nepovolí jiný režim.
6. Nepřidávej OpenAI, Anthropic ani jiný serverový API klíč do klientské aplikace.
7. Neprováděj automatický fallback mezi `school-gateway` a `direct-gemini`.
8. V první fázi neupravuj kód. Nejprve proveď audit a vyčkej na schválení implementace.

---

# FÁZE A — AUDIT BEZ ÚPRAV KÓDU

## 1. Filtr použitelnosti

Zařaď aplikaci:

- **A:** bez AI operací — Core se neintegruje;
- **B:** 1–2 jednoduché AI operace — tenký aplikační wrapper nad Core;
- **C:** 3+ operací nebo vícefázové workflow — Core plus aplikační orchestrace.

Volbu zdůvodni.

## 2. Současná architektura

Uveď konkrétní soubory a funkce pro:

- vstupní body a build;
- AI volání;
- API klíče;
- modely, retry a fallback;
- prompty;
- výstupní JSON schémata;
- timeout a zrušení;
- telemetrii;
- anonymizaci a preflight;
- service worker a CSP;
- integraci s AI Studiem.

## 3. Registr AI operací

Vytvoř tabulku:

| appId + operation | Spouštěč | Běžné provider requests | Maximum | Výstupů | Profil | Schema ID |
|---|---|---:|---:|---:|---|---|

Rozlišuj uživatelskou akci, logický AI request, provider requests, retry a výsledné výstupy. U vícefázového workflow navrhni `workflowId` a stabilní názvy jednotlivých kroků.

## 4. Provider-specifické funkce

Prověř a výslovně uveď:

- streaming;
- obrázky, audio a dokumenty;
- grounding/search;
- code execution;
- tools/function calling;
- context caching;
- thinking/reasoning nastavení;
- JSON mode a response schema;
- safety settings;
- modelový fallback;
- jiné funkce bez jistého ekvivalentu.

U každé používané funkce napiš dopad přechodu na School Gateway a případný fallback.

## 5. Vstupy a velikosti

Uveď:

- zda stačí textový `input.parts`;
- zda jsou potřeba image/document parts;
- maximální současnou velikost vstupu;
- vhodný klientský UX limit;
- limit, který musí tvrdě vynucovat gateway.

## 6. Bezpečnost a data

Uveď:

- co se anonymizuje lokálně;
- co se reálně odesílá providerovi;
- že `privacy` flags jsou pouze diagnostická klientská tvrzení;
- zda se někde loguje prompt nebo odpověď;
- jak bude ověřeno, že osobní Gemini klíč nemůže uniknout do gateway payloadu;
- jaké údaje nesmějí být v telemetrii.

## 7. Návrh integrace Core 1.0.0

Navrhni pouze aplikační integrační soubory. Nevytvářej vlastní klient ani transporty.

Uveď:

- kam se bez úprav vloží vydané Core artefakty;
- jak build ověří jejich SHA-256;
- jak se připojí existující Gemini klíč přes `credentialProvider`;
- jak se stará veřejná funkce zachová jako kompatibilní wrapper;
- jak budou operace registrovány;
- jak se vstup převede na `inputParts`;
- jak se použije `schemaId` místo klientem zaslaného libovolného schématu;
- jak se zachová stávající sémantická validace výsledku;
- jak se nastaví `defaultMode`, `allowedModes`, vědomá volba a rollback.

## 8. Distribuce a testy

Uveď:

- jak se vydané Core artefakty převezmou z migračního balíčku a později ze Studio sync;
- jak build ověří `coreVersion`, `buildId` a SHA-256;
- jak se spustí beze změn vydaná konformitní sada;
- které stávající regresní testy zůstanou;
- které nové aplikační testy jsou nutné.

## 9. Odhad rozsahu

Povinně uveď:

| Položka | Odhad |
|---|---|
| Počet dotčených souborů | |
| Počet nových aplikačních souborů | |
| Riziko | nízké / střední / vysoké |
| Lze provést v jednom průchodu | ano / ne |
| Doporučené pořadí balíčků | |
| Hlavní regresní riziko | |

## 10. Akceptační kritéria

Vytvoř krátký konkrétní checklist vycházející z `ghrab-ai-contract-v1.0.0.md` a skutečné architektury aplikace.

Po auditu vyčkej na můj souhlas. Kód zatím neměň.

---

# FÁZE B — IMPLEMENTACE PO SCHVÁLENÍ

Po schválení:

1. Vlož přesné Core artefakty bez úprav.
2. Přidej pouze aplikační manifest operací, lokální output schemas a integrační hooky.
3. Připoj existující osobní Gemini klíč přes `credentialProvider`.
4. Nahraď přímá provider volání voláním `GHRAB_AI.generate()` nebo `GHRAB_AI.stream()`.
5. Zachovej staré funkce jako dočasné kompatibilní wrappery, pokud je používají jiné moduly.
6. Zaveď `inputParts`, `schemaId`, `clientRequestId`, nový `attemptId` a `workflowId`, kde je potřeba.
7. Výchozí runtime nastav:

```javascript
ai: {
  defaultMode: "direct-gemini",
  allowedModes: ["direct-gemini"],
  allowUserModeSelection: false,
  automaticFallback: false
}
```

8. V UI zobraz aktivní režim; Gemini klíč skryj pouze v aktivním gateway režimu.
9. Nepoužívej serverový text chyby. Uživatelské chyby formátuj přes `GHRAB_AI.formatUserError()`.
10. Hodnoty `privacy.clientAnonymized`, `privacy.preflightPassed` a `maxOutputTokensHint` považuj za klientská tvrzení či návrhy, nikoli za serverová oprávnění nebo tvrdé limity.
11. V gateway režimu považuj server za autoritu pro provider requesty, retry, tokeny, cenu a limity.
12. Spusť vydanou konformitní sadu beze změn a všechny aplikační regresní testy.
13. Ověř build, service worker, CSP, manifest a nasaditelný balíček.
14. Aktualizuj verzi, changelog a technickou dokumentaci.

## Povinné výsledky implementace

Dodej:

- zdrojový ZIP;
- nasaditelný build;
- výsledky aplikačních i konformitních testů;
- seznam změněných souborů;
- SHA-256 ověření Core;
- manifest AI operací;
- seznam provider-specifických funkcí a jejich řešení;
- návod k vědomému přepnutí a rollbacku;
- seznam kroků, které zůstanou až na skutečný školní server.

Nevydávej práci za hotovou, pokud neprojde Core conformance suite, aplikační regresní testy a build.

---

# POVINNÁ METADATA PRO CENTRÁLNÍ AI STUDIO

Implementace není kompletní bez strojově čitelné evidence pro AI Studio.

1. V kořeni nasazovaného webu vytvoř veřejný `ai-operations.json` se schématem `ghrab-ai-operations-v1`. Musí obsahovat `appId`, `appVersion`, `coreVersion`, `contractVersion` a úplný seznam registrovaných operací se `schemaId`, profily, typy vstupu, streamingem a tokenovým hintem.
2. Do `studio-manifest.json` přidej blok `aiCore` se schématem `ghrab-ai-app-integration-v1`, přesnou Core a contract verzí, `serverReady`, `conformancePassed`, HTTPS URL registru operací, runtime schématem a časem certifikace.
3. Build musí ověřit, že veřejný registr operací je konzistentní se skutečnou aplikační integrací a že manifest neprohlašuje úspěšnou konformitu bez skutečně prošlé vydané sady.
4. Přidej spotřebitelský GitHub workflow pro budoucí `repository_dispatch` událost `ghrab-ai-core-released`. Workflow smí převzít pouze artefakty, které projdou SHA-256 kontrolou, konformitní sadou a aplikačním buildem/testy.
5. AI Studio považuje aplikaci za živě server-ready až podle skutečně publikovaného manifestu. Lokální test nebo ZIP je pouze certifikace čekající na nasazení.
