# GHRAB AI Migration Kit 1.0.3

Do nového vlákna nahrajte:

1. nejaktuálnější zdrojový ZIP aplikace;
2. tento balíček `ghrab-ai-migration-kit-1.0.3.zip`.

Napište: „Použij integrační prompt obsažený v Migration Kitu. Automaticky zjisti název, App ID a verzi ze zdrojů a proveď nejprve Fázi A bez úprav kódu.“

Prompt je v `prompt-integrace-aplikace-ghrab-ai-core-v3.2.md`. Core v adresáři `core/` je neměnný. Implementace musí navíc publikovat `ai-operations.json`, blok `aiCore` ve Studio manifestu a připravit budoucí consumer workflow.

## Bezpečnost automatické synchronizace v 1.0.3

Ukázkové workflow je záměrně konzervativní. Přijímá manifest jen z důvěryhodné HTTPS cesty AI Studia, ověřuje identitu vydání i SHA-256 a změny publikuje jako draft pull request. Před aktivací v konkrétní aplikaci nastavte skutečnou produkční doménu Studia a zachovejte ochranu hlavní větve.

Adresář `core/` se proti 1.0.2 nezměnil. Reference na KS 5.9.0 uvnitř neměnného kontraktu jsou historické příklady; aktuální referenční implementace pro P0 je KS 5.9.13.
