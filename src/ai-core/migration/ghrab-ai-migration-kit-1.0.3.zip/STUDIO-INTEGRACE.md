# Integrace s AI Studiem

AI Studio distribuuje neměnnou verzi Core a eviduje připravenost aplikací. Každá aplikace musí publikovat blok `aiCore` ve svém `studio-manifest.json` a samostatný `ai-operations.json`. Živý stav se uzná až po načtení publikovaného manifestu; lokální certifikace se vede odděleně.
