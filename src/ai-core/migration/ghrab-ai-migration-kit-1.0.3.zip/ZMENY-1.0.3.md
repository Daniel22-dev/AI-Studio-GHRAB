# GHRAB AI Migration Kit 1.0.3 — změny

## Co se změnilo

- integrační prompt správně odkazuje na balíček `1.0.3`;
- aktuální referenční aplikací je Korespondenční asistent 5.9.13;
- příklad consumer workflow přijímá manifest pouze z důvěryhodné cesty AI Studia;
- payload, schema, `coreVersion`, `contractVersion`, `buildId` a SHA-256 artefaktů se ověřují před publikací;
- automatizace už nepushuje přímo do hlavní větve, ale vytváří draft pull request;
- `npm ci`, konformitní testy a aplikační release gate zůstávají povinné.

## Co se nezměnilo

Adresář `core/` je bajtově shodný s vydáním v Migration Kitu 1.0.2. GHRAB AI Core 1.0.0, konformitní sada 1.0.0, kontrakt a manifest nebyly upraveny. Historická verze KS 5.9.0 uvnitř neměnného kontraktu je pouze příklad hodnoty `appVersion`, nikoli doporučení k nasazení.
